# 2544X Bolted Override

This is Team 2544X Bolted's VEX V5 PROS/EZ-Template robot code. It is shared so teammates, judges, and other builders can understand the architecture and the engineering decisions behind it.

This is not a drop-in template. The constants, port choices, right-side drive compensation, replay deadbands, HUD flow, and driver controls are tuned around one robot and one driver workflow. Copying the files and changing the logo is the fastest way to inherit someone else's bugs.

## Robot Profile

- Drivetrain: 4 motor tank drive
- Drive ports: left `1, 2`; right `4, 5` reversed in code
- IMU port: `7`
- Drive cartridge: `600 RPM`
- External gearing: `36` tooth driving gear to `60` tooth driven gear
- Main auton storage: SD card when present, RAM fallback while powered on
- Auton slots: `QUAL`, `SKILLS`, `Q MIR`, `S MIR`

## Driver Modes

- `MATCH`: normal field-safe driving and selected auton replay.
- `REC`: path recording mode. Hold `L1` and press `UP` to start, hold `L1` and press `DOWN` to save. Press `R2` to swap between `QUAL` and `SKILLS` slots.
- `PIT`: pit check mode. Press `L2` to run the motor check when not connected to field control.

When VEXnet/field control is connected, the code forces `MATCH` mode so record and pit tools cannot be selected by accident on the field.

## How To Read This Project

Start with these docs:

- `docs/ARCHITECTURE.md`: how the major systems fit together.
- `docs/AUTON_REPLAY_CONCEPTS.md`: how the record/replay auton works.
- `docs/ADAPTATION_CHECKLIST.md`: everything a different robot would have to redesign before using the ideas.

Then read the code in this order:

1. `src/main.cpp`
2. `include/subsystems.hpp`
3. `src/driver_assist.cpp`
4. `src/path_recorder.cpp`
5. `src/competition_ui.cpp`

## Build

From this folder:

```powershell
pros make
```

To upload, connect the V5 Brain over USB or controller tether and run:

```powershell
pros upload
```

## Reuse Policy

Use the concepts. Credit the team. Do not present this robot-specific code as your own team's original system after a logo swap. See `NOTICE.md`.

