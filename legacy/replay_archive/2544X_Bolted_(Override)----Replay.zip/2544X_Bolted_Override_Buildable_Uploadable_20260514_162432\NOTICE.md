# Notice

This project represents Team 2544X Bolted's robot-specific competition code and workflow.

Unless a separate `LICENSE` file is added by the team, this repository is not being published as an open-source template. You may read it to understand the concepts, but you should not copy, rebrand, and submit it as another team's original work.

If you adapt ideas from this code, give credit and rewrite the robot-specific pieces for your own hardware, driver, sensors, and strategy.

