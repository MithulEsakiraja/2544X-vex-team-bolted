# Judges Guide

This project is built around making autonomous recording usable by drivers without making the match program dangerous.

## What Makes It Different

- The Brain HUD separates match driving, recording, pit check, and auton selection.
- Field control forces match mode, so recording tools cannot be selected during a match.
- Auton replay has two saved paths: `QUAL` and `SKILLS`.
- Each path can run mirrored from the HUD.
- Saved paths use SD when present and RAM fallback when SD is missing.
- Replay uses heading, drive encoder distance, voltage, and anti-tip checks.
- Tiny stopped-side commands are scrubbed so a side does not twitch during replay.

## Driver Workflow

The driver records a route in `REC`, saves it, checks that the HUD says the slot is ready, then selects that slot for match auton. During field control, the robot locks to `MATCH`.

## Engineering Tradeoffs

This is not magic odometry. It is a practical replay system for a tank drive robot. The code is designed so the team can tune real sources of miss:

- wheel slip
- battery variation
- IMU drift
- motor imbalance
- tiny joystick leftover commands
- field tile differences

The code keeps these assumptions visible because that makes the system easier to explain and debug.

