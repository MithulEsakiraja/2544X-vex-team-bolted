# Auton Replay Concepts

The replay system records what the driver did, then plays it back with small corrections so the robot can repeat the route more consistently.

## Recording

In `REC` mode:

1. Press `R2` to choose `QUAL` or `SKILLS`.
2. Hold `L1` and press `UP` to start.
3. Drive the route.
4. Hold `L1` and press `DOWN` to stop and save.

Every recorded frame stores:

- elapsed time
- left drive command
- right drive command
- robot heading
- left drive motor position average
- right drive motor position average

The current recorder interval is `1 ms`. Status text is throttled so the screen/controller do not steal time from the recorder loop.

## Storage

The code saves to SD first:

- `/usd/qual_replay.csv`
- `/usd/skills_replay.csv`

If SD is missing, it keeps the path in RAM. RAM paths are lost when the Brain turns off.

## Replay

Replay follows the recorded timestamps, then sends tank commands back to the left and right sides.

The replay also uses:

- heading correction to resist drift
- distance correction from drive encoder averages
- voltage scaling to reduce battery variation
- anti-tip limiting from IMU pitch/roll
- right-side scaling for this robot's drive behavior

## Stopped-Side Lockout

Tiny joystick leftovers can cause small unwanted rotations. The replay now scrubs tiny commands and locks a stopped side to true zero.

That means if the left side was basically stopped during recording, correction code is not allowed to wake it up during replay. Same for the right side.

## Why This Is Not Portable

A different robot must retune at least:

- wheel diameter
- gear ratio
- motor cartridge
- motor polarity
- IMU mounting
- encoder polarity
- right/left friction balance
- replay deadband
- heading correction
- distance correction
- driver path timing

That is the point: the concept is reusable, but the saved behavior is a 2544X robot fingerprint.

